# vertical-prototype
Vertical prototype for the clubs and events website
